package com.unipigiorgos.smartalert;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.nfc.Tag;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.sql.Timestamp;

public class ReportActivity extends AppCompatActivity implements LocationListener {
    LocationManager locationManager;
    EditText editText;
    String cords;
    FirebaseDatabase database;
    DatabaseReference reference;
    FirebaseAuth mAuth;
    int code = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        editText = findViewById(R.id.editTextTextPersonName2);
        Spinner spinnerCat = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.category, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinnerCat.setAdapter(adapter);
        database = FirebaseDatabase.getInstance();
        mAuth = FirebaseAuth.getInstance();
        reference = database.getReference(mAuth.getUid());

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},321);
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
    }



    public void report(View view) {
        code += 1;
        String x1, x2;
        Spinner spinner = findViewById(R.id.spinner);
        x1 = editText.getText().toString();
        x2 = spinner.getSelectedItem().toString();
        int time = (int) (System.currentTimeMillis());
        Timestamp tsTemp = new Timestamp(time);
        String ts = tsTemp.toString();
        //showMessage("test", x1 + x2 + cords + ts);
        //reference.child(String.valueOf(code)).setValue(x1+"-"+x2+"-"+ts+"-"+cords);
        reference.push().child(String.valueOf(code)).setValue(x1+"-"+x2+"-"+ts+"-"+cords);
        //showMessage("Done","incident Reported!");
        Context context = getApplicationContext();
        CharSequence text = "Incident Reported!";
        int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();

    }

    public void showMessage(String title,String text) {
        new AlertDialog.Builder(this)
                .setCancelable(true)
                .setTitle(title)
                .setMessage(text)
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {

        cords = location.getLatitude()+","+location.getLongitude();

    }
}