package com.unipigiorgos.smartalert;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    EditText email,password;
    FirebaseAuth mAuth;
    Button signUp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        email = findViewById(R.id.editTextTextPersonName);
        password = findViewById(R.id.editTextTextPassword);
        mAuth = FirebaseAuth.getInstance();
        signUp = findViewById(R.id.button);
        if(LaunchActivity.title.equals("admin")){
            signUp.setEnabled(false);
        }


    }
    void showMessage(String title, String message){
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setCancelable(true).show();
    }

    public void signup(View view){
        mAuth.createUserWithEmailAndPassword(email.getText().toString(),password.getText().toString())
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            showMessage("Success!","User authenticated");
                        }else{
                            showMessage("Error",task.getException().getLocalizedMessage());
                        }
                    }
                });

    }

    public void signin(View view){
        if(email.getText().toString().equals("admin@unipi.gr")){
            mAuth.signInWithEmailAndPassword(email.getText().toString(),password.getText().toString())
                    .addOnCompleteListener((task)->{
                        if(task.isSuccessful()){
                            showMessage("Success!","Ok");
                            //startActivity(new Intent(MainActivity.this, MainMenu.class));
                            startActivity(new Intent(MainActivity.this, AdminMenu.class));
                        }else{
                            showMessage("Error",task.getException().getLocalizedMessage());
                        }
                    });
        }else {
            if(email.getText().toString() != "" && password.getText().toString() != ""){
                mAuth.signInWithEmailAndPassword(email.getText().toString(),password.getText().toString())
                        .addOnCompleteListener((task)->{
                            if(task.isSuccessful()){
                                showMessage("Success!","Ok");
                                startActivity(new Intent(MainActivity.this, MainMenu.class));
                            }else{
                                showMessage("Error",task.getException().getLocalizedMessage());
                            }
                        });


            }

        }


    }
}