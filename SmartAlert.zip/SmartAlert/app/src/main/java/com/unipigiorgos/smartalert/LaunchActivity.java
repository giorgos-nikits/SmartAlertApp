package com.unipigiorgos.smartalert;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class LaunchActivity extends AppCompatActivity {

    public static String title;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launch);
    }

    public void uslogin(View view){
        title = "user";
        startActivity(new Intent(LaunchActivity.this, MainActivity.class));
    }

    public void logAdm(View view){
        title = "admin";
        startActivity(new Intent(LaunchActivity.this, MainActivity.class));

    }
}